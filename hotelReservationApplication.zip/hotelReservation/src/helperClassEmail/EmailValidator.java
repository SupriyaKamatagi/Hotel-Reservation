package helperClassEmail;

import java.util.regex.Pattern;

public class EmailValidator {
    private static String emailRegEx="^(.+)@(.+).com$";
    private static Pattern pattern=Pattern.compile(emailRegEx);
    public static boolean isValid(String email){
        if(!pattern.matcher(email).matches()){
            throw new IllegalArgumentException("Invalid Email!! please try again");
        }
        return pattern.matcher(email).matches();
    }
    public static String getEmailRegEx(){
        return emailRegEx;
    }
    public static Pattern getPattern(){
        return Pattern.compile(emailRegEx);
    }

}
