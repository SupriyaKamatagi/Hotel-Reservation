package API;

import Service.CustomerService;
import Service.ReservationService;
import model.Customer;
import model.IRoom;

import java.util.Collection;
import java.util.List;

public class AdminResource {
    private static ReservationService reservationService = new ReservationService();
    public static ReservationService getInstance() {
        return reservationService;
    }
    public static Customer getCustomer(String email){
        CustomerService customerService = CustomerService.getSingleton();
        return customerService.getCustomer(email);
    }
    public static void addRoom(List<IRoom> rooms){
        ReservationService reservationService = ReservationService.getSingleton();
        for (IRoom roomi: rooms) {
            reservationService.addRoom(roomi);
        }
    }

    public static Collection<IRoom> getAllRooms(){
        ReservationService reservationService= ReservationService.getSingleton();
        return reservationService.getAllRooms();
    }

    public static Collection<Customer> getAllCustomers(){
        CustomerService customerService = CustomerService.getSingleton();
        return customerService.getAllCustomers();
    }
    public static void displayAllReservations(){
        ReservationService reservationService = ReservationService.getSingleton();
        reservationService.printAllReservation();
    }
}
