package Service;

import model.Customer;
import model.Room;
import model.RoomType;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class TestReservationService {
    public static void main(String[] args) throws ParseException {
        String checkIn ="19-09-2020";
        String checkout="28-09-2020";
        String anotherDateStr1 = "3-10-2020";
        String anotherDateStr2 = "7-10-2020";
        SimpleDateFormat formatter = new SimpleDateFormat("dd-mm-yyyy");
        Date checkInDate = formatter.parse(checkIn);
        Date checkOutDate = formatter.parse(checkout);
        Date anotherDate1 = formatter.parse(anotherDateStr1);
        Date anotherDate2 = formatter.parse(anotherDateStr2);

        ReservationService ReservationServices = ReservationService.getSingleton();
        Customer first = new Customer("Leon","Le","Leon@gmail.com");
        RoomType enum1= RoomType.DOUBLE;
        Room firstRoom = new Room("222",98.3,enum1,true);
        ReservationServices.reserveARoom(first, firstRoom,checkInDate,checkOutDate);

        ReservationServices.printAllReservation();
        System.out.println(ReservationServices.findRooms(anotherDate1,anotherDate2));
        System.out.println(ReservationServices.getCustomerReservation(first));

        Room secondRoom = new Room("555",12.0,enum1,false);
        ReservationServices.reserveARoom(first,secondRoom,anotherDate1,anotherDate2);
        ReservationServices.printAllReservation();
        System.out.println(ReservationServices.getCustomerReservation(first));

    }
}
