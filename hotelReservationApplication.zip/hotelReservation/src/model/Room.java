package model;

public class Room implements IRoom{
    private String roomNumber;
    private Double price;
    private RoomType roomType;
    private  boolean isFree;

    public Room(){

    }

    public Room(String roomNumber,Double price,RoomType roomType,boolean isFree){
        this.roomNumber=roomNumber;
        this.price=price;
        this.roomType=roomType;
        this.isFree=isFree;
    }


    public String getRoomNumber() {
        return roomNumber;
    }

    public Double getRoomPrice() {
        return price;
    }

    public RoomType getRoomType() {
        return roomType;
    }

    public boolean getIsFree() {
        return isFree;
    }

    public void setRoomNumber(String roomNumber){
        this.roomNumber=roomNumber;
    }

    public void setRoomPrice(Double price){
        this.price=price;
    }

    public void setRoomType(RoomType roomType){
        this.roomType=roomType;
    }


    public void setIsFree(Boolean isFree) {
         this.isFree=isFree;
    }

    @Override
    public String toString(){
        return "Room{ " + "roomNumber: "+roomNumber+'\''+", roomPrice: "+price+" roomType: "+roomType+" isRoomFree: "+isFree+'}';
    }

}
