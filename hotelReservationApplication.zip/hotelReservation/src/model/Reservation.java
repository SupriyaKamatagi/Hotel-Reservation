package model;

import java.util.Date;
import java.util.Objects;

public class Reservation {
private Customer customer;
private IRoom room;
private Date checkInDate;
private Date checkOutDate;

public Reservation(Customer customer,IRoom room,Date checkInDate,Date checkOutDate){
    this.room=room;
    this.customer=customer;
    this.checkInDate=checkInDate;
    this.checkOutDate =checkOutDate;
}

public Customer getCustomer(){
    return customer;
}

public IRoom getRoom(){
    return room;
}

public Date getCheckInDate(){
    return checkInDate;
}

public Date getCheckOutDate(){
    return checkOutDate;
}

public void setCustomer(Customer customer){
    this.customer=customer;
}

public void setRoom(Room room){
    this.room=room;
}

public void setCheckInDate(Date checkInDate){
    this.checkInDate=checkInDate;
}
public void setCheckOutDate(Date checkOutDate){
    this.checkOutDate=checkOutDate;
}

@Override
    public String toString(){
    return "Reservation{" + " Customer: "+ customer+" ,room: "+room+" ,CheckInDate: "+checkInDate+" ,CheckOutDate: "+checkOutDate+'}';
}
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Reservation that = (Reservation) o;
        return Objects.equals(customer, that.customer) && Objects.equals(room, that.room)
                && Objects.equals(checkInDate, that.checkInDate) && Objects.equals(checkOutDate, that.checkOutDate);
    }

    @Override
    public int hashCode() {
        return Objects.hash(customer, room, checkInDate, checkOutDate);
    }


}
