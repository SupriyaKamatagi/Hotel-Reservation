package model;

import java.util.Date;

public class TestReservation {
    public static void main(String[] args){
        Customer customer=new Customer("Jholly","Jully","jully@email.com");
        FreeRoom freeRoom=new FreeRoom("717",999.0,RoomType.SINGLE,true);
        Date checkInDate= new Date(2022,04,03);
        Date checkOutDate= new Date(2022,04,10);
        Reservation reservation=new Reservation(customer,freeRoom,checkInDate,checkOutDate);
        System.out.println(reservation.toString());
    }
}
