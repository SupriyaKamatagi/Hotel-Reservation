package model;

public class TestCustomer {
    public static void main(String[] args){
        try{
            Customer customer=new Customer("Jhon","Link","Jhon@gmail.com");
            System.out.println(customer.toString());
        }catch (IllegalArgumentException ex){
            System.out.println(ex.getLocalizedMessage());
        }
    }
}
