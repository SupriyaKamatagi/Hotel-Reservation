package main;

import Menu.MainMenu;

public class Main {
    public  static void main(String[] args){
        MainMenu.showMainMenu();
    }
}
