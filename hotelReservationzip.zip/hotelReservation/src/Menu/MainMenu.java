package Menu;

import API.AdminResource;
import API.HotelResource;
import model.Customer;
import model.IRoom;
import model.Reservation;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainMenu {
    public static  void  showMainMenu(){
        try(Scanner scanner = new Scanner(System.in)){
            while (flag){
                System.out.println(mainMenuText);
                while(scanner.hasNext()){
                    while (!scanner.hasNext()){
                        System.out.println("Please input 1 to 5");
                        scanner.next();
                    }
                    int temp=scanner.nextInt();
                    if(temp>= 1 && temp<=5){
                        scanner.nextLine();
                        handleUserInput(scanner, temp);
                        break;
                    }
                    System.out.println("Please input 1 to 5");
                }
            }
        }catch (Exception ex){
            ex.getLocalizedMessage();
        }
    }

    protected  static void handleUserInput(Scanner scanner, int userInput){
        switch (userInput){
            case 1 -> findAndReserveARoom(scanner);
            case 2 -> seeMyReservations(scanner);
            case 3 -> createAnAccount(scanner);
            case 4 -> AdminMenu.showAdminMenu(scanner);
            case 5 -> flag=false;
            default -> throw new IllegalArgumentException(" Unexpected value: "+ userInput);
        }
    }
    private  static void findAndReserveARoom(Scanner scanner){
        SimpleDateFormat bookingDateFormat = new SimpleDateFormat("mm/ddd/yyyy");
        System.out.println("Enter your check-In Date in the Format mm/ddd/yyyy"+"E.g.:32/1/2020");
        Date checkInDate = null;
        try{
            checkInDate = bookingDateFormat.parse(scanner.nextLine());
        }catch (ParseException e){
            e.printStackTrace();
        }
        System.out.println("Enter your check-out Date in the Format dd/mm/yyyy"+"E.g.: 3/30/2020");
        Date checkOutDate = null;
        try{
            checkOutDate = bookingDateFormat.parse(scanner.nextLine());
        }catch (ParseException e){
            e.printStackTrace();
        }
        System.out.println();
        Collection<IRoom> availableRooms = HotelResource.findARoom(checkInDate, checkOutDate);

        while(availableRooms.isEmpty()){
            System.out.println("There are no available rooms between these dates."+"\n"+"These are my recommendation:");
            Calendar calendar = new GregorianCalendar();
            assert checkInDate != null;
            calendar.setTime(checkInDate);
            calendar.add(Calendar.DATE,7);
            checkInDate=calendar.getTime();
            availableRooms= HotelResource.findARoom(checkInDate, checkOutDate);
            System.out.println("Available rooms from: " + checkInDate+" to "+ checkOutDate);
        }
        for(IRoom room:availableRooms){
            System.out.println(room);
        }
        String email = "name@domain.com";
        System.out.println("Do you have an account? select (y/n) ");
        char userChoice = scanner.nextLine().trim().charAt(0);
        if(userChoice == 'y'){
            System.out.println("Enter your Email: name@domain.com ");
            String tempEmail = scanner.nextLine();
            Customer customer = AdminResource.getCustomer(tempEmail);
            if(customer==null){
                email = createAnAccount(scanner);
            }else {
                System.out.println(" Illegal input! Please input y/n.");
                return;
            }
            System.out.println("The room number is not valid. Please input again.");
        }
    }

    private static void seeMyReservations(Scanner scanner){
        System.out.println("Enter your Email: ");
        String email = scanner.next();
        if (HotelResource.getCustomer(email)!=null){
            for (Reservation reservation:HotelResource.getCustomerReservations(email)){
                System.out.println(reservation);
            }
        }else {
            System.out.println(" Can't find any reservations!"+"\n");
        }
    }
    private static String createAnAccount(Scanner scanner){
        System.out.println("Enter your First Name:");
        String firstName = scanner.nextLine();

        System.out.println("Enter your Last Name:");
        String lastName = scanner.nextLine();

        System.out.println("Enter your Email: name@domain.com");
        String email = scanner.nextLine();
        try{
            HotelResource.createACustomer(email,firstName,lastName);
        }catch (IllegalArgumentException ex){
            System.out.println(ex.getLocalizedMessage());
            return null;
        }
        System.out.println();
        System.out.println("Name: "+firstName+" Last "+lastName+" ,Email: "+email);
        System.out.println();
        return email;
    }
    protected static boolean flag=true;
    protected static final  String mainMenuText= """
            Welcome to the Hotel Reservation Application
            -----------------------------------------------
            1. Find and Reserve a room
            2. See my reservations
            3. Create an account
            4. Admin
            5. Exit
            -----------------------------------------------
            Please select a number for the menu option
            
            """;

}
