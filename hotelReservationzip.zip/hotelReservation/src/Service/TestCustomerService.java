package Service;

public class TestCustomerService {
    public static void main(String[] args){
        CustomerService customerService = CustomerService.getSingleton();
        customerService.addCustomer("william@gmail.com","William","w");
        System.out.println(customerService.getCustomer("Mike@gmail.com"));
        customerService.addCustomer("Jessy@gmail.com","Jessy","J");
        System.out.println(customerService.getAllCustomers());
    }
}
