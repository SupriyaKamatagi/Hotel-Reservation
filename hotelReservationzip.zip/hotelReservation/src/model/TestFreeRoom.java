package model;

public class TestFreeRoom {
    public static void main(String[] args){
        FreeRoom freeRoom=new FreeRoom("212",99.90,RoomType.DOUBLE,true);
        System.out.println(freeRoom.toString());
    }
}
