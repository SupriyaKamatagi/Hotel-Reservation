package model;

public class TestRoom {
    public static void main(String[] args){
        RoomType enum1=RoomType.DOUBLE;
        Room room1= new Room("CornerRoom",89.8,enum1,true);
        System.out.println(room1.toString());
       // room2=new FreeRoom("withBalcony",enum1);
       // System.out.println((room2.toString()));
    }
}
