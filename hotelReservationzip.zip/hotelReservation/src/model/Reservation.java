package model;

import java.util.Date;

public class Reservation {
private Customer customer;
private IRoom room;
private Date checkInDate;
private Date checkOutDate;

public Reservation(Customer customer,IRoom room,Date checkInDate,Date checkOutDate){
    this.room=room;
    this.customer=customer;
    this.checkInDate=checkInDate;
    this.checkOutDate =checkOutDate;
}

public Customer getCustomer(){
    return customer;
}

public IRoom getRoom(){
    return room;
}

public Date getCheckInDate(){
    return checkInDate;
}

public Date getCheckOutDate(){
    return checkOutDate;
}

public void setCustomer(Customer customer){
    this.customer=customer;
}

public void setRoom(Room room){
    this.room=room;
}

public void setCheckInDate(Date checkInDate){
    this.checkInDate=checkInDate;
}
public void setCheckOutDate(Date checkOutDate){
    this.checkOutDate=checkOutDate;
}

@Override
    public String toString(){
    return "Reservation{" + " Customer: "+ customer+" ,room: "+room+" ,CheckInDate: "+checkInDate+" ,CheckOutDate: "+checkOutDate+'}';
}


}
